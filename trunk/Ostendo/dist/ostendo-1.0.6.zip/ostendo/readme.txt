Setting up of Ostendo:

- unzip the distribution

run using ant:

ant rundemo

