package de.jwi.ostendo.test;


/*
 * Ostendo - CORBA IIOP Message Analyzer
 * 
 * Copyright (C) 2006 Juergen Weber
 * 
 * This file is part of Ostendo.
 * 
 * Ostendo is free software; you can redistribute it and/or modify it under the terms of the GNU General Public
 * License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later
 * version.
 * 
 * Ostendo is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied
 * warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with Ostendo; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place, Suite 330, Boston
 */

import de.jwi.ostendo.Ostendo;


/**
 * @author Juergen Weber 
 * Created on 12.08.2006
 */
public class OstendoTester
{
	public static void main(String[] args) throws Exception
	{
		String iorName = "ior.txt";
		
		String idlName = "src/ostendo/test/server.idl";
		

		//		String msgname = "getData_0.bin";
//				String msgname = "handleNested_2.bin";
//		String msgname = "sendArrays_4.bin";

//		String msgname = "sendSequences_6.bin";
		
//		String msgname = "writeUnions_8.bin";
		
//		String msgname = "changeCurrency_10.bin";
		
		String msgRequest = "messagelog/getData-2-Request.bin";
		String msgReply = "messagelog/getData-2-Reply.bin";
		
		String[] oargs = {iorName, idlName, msgRequest, msgReply};
		
		Ostendo.main(oargs);
	}

}
