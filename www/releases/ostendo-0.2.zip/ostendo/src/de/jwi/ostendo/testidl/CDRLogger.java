package de.jwi.ostendo.testidl;

/*
 * Ostendo - CORBA IIOP Message Analyzer
 * 
 * Copyright (C) 2006 Juergen Weber
 * 
 * This file is part of Ostendo.
 * 
 * Ostendo is free software; you can redistribute it and/or modify it under the terms of the GNU General Public
 * License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later
 * version.
 * 
 * Ostendo is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied
 * warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with Ostendo; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place, Suite 330, Boston
 */


import java.io.IOException;
import java.io.OutputStreamWriter;


/**
 * @author Juergen Weber 
 * Created on 11.08.2006
 */
public class CDRLogger
{
	int read_Object_count;
	int read_any_count;
	int read_TypeCode_count;
	int read_boolean_count;
	int read_char_count;
	int read_double_count;
	int read_float_count;
	int read_long_count;
	int read_longlong_count;
	int read_octet_count;
	int read_short_count;
	int read_string_count;
	int read_ulong_count;
	int read_ushort_count;
	int read_wchar_count;
	int read_wstring_count;

	int read_boolean_array_count;
	int read_char_array_count;
	int read_double_array_count;
	int read_float_array_count;
	int read_long_array_count;
	int read_longlong_array_count;
	int read_octet_array_count;
	int read_short_array_count;
	int read_ulong_array_count;
	int read_ulonglong_array_count;
	int read_ushort_array_count;
	int read_wchar_array_count;

	

	OutputStreamWriter ow = null;
	
	
	public void close()
	{
		try
		{
			ow.close();
		}
		catch (IOException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void log(String value) 
	{
		System.out.println(value);
	}
	
	public void log(short value) 
	{
		log(Short.toString(value));
	}

	public void log(short[] value) 
	{
		for (int i=0;i<value.length;i++)
		{
			log(value[i]);
		}
	}

	
	public void log(int value) 
	{
		log(Integer.toString(value));
	}

	public void log(int[] value) 
	{
		for (int i=0;i<value.length;i++)
		{
			log(value[i]);
		}
	}
	
	public void log(long value) 
	{
		log(Long.toString(value));
	}

	public void log(long[] value) 
	{
		for (int i=0;i<value.length;i++)
		{
			log(value[i]);
		}
	}

	
	public void log(boolean value) 
	{
		log(Boolean.toString(value));
	}

	public void log(boolean[] value) 
	{
		for (int i=0;i<value.length;i++)
		{
			log(value[i]);
		}
	}
	
	
	public void log(byte value) 
	{
		log(Byte.toString(value));
	}

	public void log(byte[] value) 
	{
		for (int i=0;i<value.length;i++)
		{
			log(value[i]);
		}
	}
	
	
	public void log(char value) 
	{
		log(Character.toString(value));
	}

	public void log(char[] value) 
	{
		for (int i=0;i<value.length;i++)
		{
			log(value[i]);
		}
	}
	
	
	public void log(double value) 
	{
		log(Double.toString(value));
	}

	public void log(double[] value) 
	{
		for (int i=0;i<value.length;i++)
		{
			log(value[i]);
		}
	}
	
	
	public void log(float value) 
	{
		log(Float.toString(value));
	}

	public void log(float[] value) 
	{
		for (int i=0;i<value.length;i++)
		{
			log(value[i]);
		}
	}
	

	
	public String toString()
	{
		StringBuffer sb = new StringBuffer();
		sb.append( " read_Object_count ")               .append(read_Object_count);
		sb.append( " read_any_count ")                  .append(read_any_count);
		sb.append( " read_TypeCode_count ")             .append(read_TypeCode_count);
		sb.append( " read_boolean_count ")              .append(read_boolean_count);
		sb.append( " read_char_count ")                 .append(read_char_count);
		sb.append( " read_double_count ")               .append(read_double_count);
		sb.append( " read_float_count ")                .append(read_float_count);
		sb.append( " read_long_count ")                 .append(read_long_count);   
		sb.append( " read_longlong_count ")             .append(read_longlong_count);
		sb.append( " read_octet_count ")                .append(read_octet_count);
		sb.append( " read_short_count ")                .append(read_short_count);
		sb.append( " read_string_count ")               .append(read_string_count);
		sb.append( " read_ulong_count ")                .append(read_ulong_count);
		sb.append( " read_ushort_count ")               .append(read_ushort_count);
		sb.append( " read_wchar_count ")                .append(read_wchar_count);
		sb.append( " read_wstring_count ")              .append(read_wstring_count);
		                                     
		sb.append( " read_boolean_array_count ")        .append(read_boolean_array_count);
		sb.append( " read_char_array_count ")           .append(read_char_array_count);                     
		sb.append( " read_double_array_count ")         .append(read_double_array_count);
		sb.append( " read_float_array_count ")          .append(read_float_array_count);
		sb.append( " read_long_array_count ")           .append(read_long_array_count);
		sb.append( " read_longlong_array_count ")       .append(read_longlong_array_count);
		sb.append( " read_octet_array_count ")          .append(read_octet_array_count);
		sb.append( " read_short_array_count ")          .append(read_short_array_count);
		sb.append( " read_ulong_array_count ")          .append(read_ulong_array_count);
		sb.append( " read_ulonglong_array_count ")      .append(read_ulonglong_array_count);      
		sb.append( " read_ushort_array_count ")         .append(read_ushort_array_count);
		sb.append( " read_wchar_array_count ")          .append(read_wchar_array_count);
		
		return sb.toString();
	}
	
}
