Setting up of Ostendo:

- unzip the distribution
- get JacORB-2.2.4
- get a recent version of xalan-j
- copy build.properties.template to build.properties and change 
  there the pathes to JacORB and xalan.
- copy the patch-2.2.4.jar into the ostendo/dist folder

run using ant:

ant rundemo

