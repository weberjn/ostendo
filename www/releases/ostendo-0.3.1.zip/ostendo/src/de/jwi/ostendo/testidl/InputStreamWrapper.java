package de.jwi.ostendo.testidl;

/*
 * Ostendo - CORBA IIOP Message Analyzer
 * 
 * Copyright (C) 2006 Juergen Weber
 * 
 * This file is part of Ostendo.
 * 
 * Ostendo is free software; you can redistribute it and/or modify it under the terms of the GNU General Public
 * License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later
 * version.
 * 
 * Ostendo is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied
 * warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with Ostendo; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place, Suite 330, Boston
 */


import java.io.IOException;
import java.io.OutputStreamWriter;

import org.omg.CORBA.Any;
import org.omg.CORBA.Object;
import org.omg.CORBA.TypeCode;


/**
 * @author Juergen Weber 
 * Created on 11.08.2006
 */
public class InputStreamWrapper extends org.omg.CORBA.portable.InputStream
{
	int read_Object_count;
	int read_any_count;
	int read_TypeCode_count;
	int read_boolean_count;
	int read_char_count;
	int read_double_count;
	int read_float_count;
	int read_long_count;
	int read_longlong_count;
	int read_octet_count;
	int read_short_count;
	int read_string_count;
	int read_ulong_count;
	int read_ushort_count;
	int read_wchar_count;
	int read_wstring_count;

	int read_boolean_array_count;
	int read_char_array_count;
	int read_double_array_count;
	int read_float_array_count;
	int read_long_array_count;
	int read_longlong_array_count;
	int read_octet_array_count;
	int read_short_array_count;
	int read_ulong_array_count;
	int read_ulonglong_array_count;
	int read_ushort_array_count;
	int read_wchar_array_count;

	

	OutputStreamWriter ow = null;
	
	org.omg.CORBA.portable.InputStream delegate;
	CDRLogger logger;
	
	public InputStreamWrapper(org.omg.CORBA.portable.InputStream is, CDRLogger logger)
	{
		delegate = is;
		this.logger=logger;
	}
	
	public void close()
	{
		try
		{
			ow.close();
		}
		catch (IOException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	public Object read_Object()
	{
		
		read_Object_count++;
		return delegate.read_Object();
	}

	public TypeCode read_TypeCode()
	{
		
		read_TypeCode_count++;
		return delegate.read_TypeCode();
	}

	public Any read_any()
	{
		
		read_any_count++;
		return delegate.read_any();
	}

	public boolean read_boolean()
	{
		boolean value = delegate.read_boolean();
		logger.log(value);
		return value;
	}

	public void read_boolean_array(boolean[] value, int offset, int length)
	{
		delegate.read_boolean_array(value,offset,length);
		logger.log(value);
	}

	public char read_char()
	{
		char value = delegate.read_char();
		logger.log(value);
		return value;
	}

	public void read_char_array(char[] value, int offset, int length)
	{
		delegate.read_char_array(value,offset,length);
		logger.log(value);
	}

	public double read_double()
	{
		double value = delegate.read_double();
		logger.log(value);
		return value;
	}

	public void read_double_array(double[] value, int offset, int length)
	{
		delegate.read_double_array(value,offset,length);
		logger.log(value);
	}

	public float read_float()
	{
		float value = delegate.read_float();
		logger.log(value);
		return value;
	}

	public void read_float_array(float[] value, int offset, int length)
	{
		delegate.read_float_array(value,offset,length);
		logger.log(value);
	}

	public int read_long()
	{
		int value = delegate.read_long();
		logger.log(value);
		return value;
	}

	public void read_long_array(int[] value, int offset, int length)
	{
		delegate.read_long_array(value,offset,length);
		logger.log(value);
	}

	public long read_longlong()
	{
		long value = delegate.read_longlong();
		logger.log(value);
		return value;
	}

	public void read_longlong_array(long[] value, int offset, int length)
	{
		delegate.read_longlong_array(value,offset,length);
		logger.log(value);
	}

	public byte read_octet()
	{
		byte value = delegate.read_octet();
		logger.log(value);
		return value;
	}

	public void read_octet_array(byte[] value, int offset, int length)
	{
		delegate.read_octet_array(value,offset,length);
		logger.log(value);
	}

	public short read_short()
	{
		short value = delegate.read_short();
		logger.log(value);
		return value;
	}

	public void read_short_array(short[] value, int offset, int length)
	{
		delegate.read_short_array(value,offset,length);
		logger.log(value);
	}

	public String read_string()
	{
		String value = delegate.read_string();
		logger.log(value);
		return value;
	}

	
	public int read_ulong()
	{
		int value = delegate.read_ulong();
		logger.log(value);
		return value;
	}

	public void read_ulong_array(int[] value, int offset, int length)
	{
		delegate.read_ulong_array(value,offset,length);
		logger.log(value);
	}

	public long read_ulonglong()
	{
		long value = delegate.read_ulonglong();
		logger.log(value);
		return value;
	}

	public void read_ulonglong_array(long[] value, int offset, int length)
	{
		delegate.read_ulonglong_array(value,offset,length);
		logger.log(value);
	}

	public short read_ushort()
	{
		short value = delegate.read_ushort();
		logger.log(value);
		return value;
	}

	public void read_ushort_array(short[] value, int offset, int length)
	{
		delegate.read_ushort_array(value,offset,length);
		logger.log(value);
	}

	public char read_wchar()
	{
		char value = delegate.read_char();
		logger.log(value);
		return value;
	}

	public void read_wchar_array(char[] value, int offset, int length)
	{
		delegate.read_wchar_array(value,offset,length);
		logger.log(value);
	}

	public String read_wstring()
	{
		String value = delegate.read_wstring();
		logger.log(value);
		return value;
	}

}
