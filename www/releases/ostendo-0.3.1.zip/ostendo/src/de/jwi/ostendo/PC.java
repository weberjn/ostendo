/*
 * Created on 03.08.2006
 *
 */
package de.jwi.ostendo;

public class PC
{

	/**
	 * @param args
	 */
	public static void main(String[] args)
	{
		org.jacorb.idl.parser.compileAndHandle(args);

	}

}
