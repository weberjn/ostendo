
package de.jwi.ostendo.testidl;

/*
 * Ostendo - CORBA IIOP Message Analyzer
 * 
 * Copyright (C) 2006 Juergen Weber
 * 
 * This file is part of Ostendo.
 * 
 * Ostendo is free software; you can redistribute it and/or modify it under the terms of the GNU General Public
 * License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later
 * version.
 * 
 * Ostendo is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied
 * warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with Ostendo; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place, Suite 330, Boston
 */


import java.io.IOException;
import java.io.OutputStreamWriter;

import org.omg.CORBA.Any;
import org.omg.CORBA.Object;
import org.omg.CORBA.TypeCode;
import org.omg.CORBA.portable.InputStream;


/**
 * @author Juergen Weber 
 * Created on 11.08.2006
 */
public class OutputStreamWrapper extends org.omg.CORBA.portable.OutputStream
{
	int read_Object_count;

	int read_any_count;

	int read_TypeCode_count;

	int read_boolean_count;

	int read_char_count;

	int read_double_count;

	int read_float_count;

	int read_long_count;

	int read_longlong_count;

	int read_octet_count;

	int read_short_count;

	int read_string_count;

	int read_ulong_count;

	int read_ushort_count;

	int read_wchar_count;

	int read_wstring_count;

	int read_boolean_array_count;

	int read_char_array_count;

	int read_double_array_count;

	int read_float_array_count;

	int read_long_array_count;

	int read_longlong_array_count;

	int read_octet_array_count;

	int read_short_array_count;

	int read_ulong_array_count;

	int read_ulonglong_array_count;

	int read_ushort_array_count;

	int read_wchar_array_count;


	OutputStreamWriter ow = null;

	org.omg.CORBA.portable.OutputStream delegate;

	CDRLogger logger;

	public OutputStreamWrapper(org.omg.CORBA.portable.OutputStream is,
			CDRLogger logger)
	{
		delegate = is;
		this.logger = logger;
	}

	public void close()
	{
		try
		{
			ow.close();
		}
		catch (IOException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}


	public InputStream create_input_stream()
	{
		return delegate.create_input_stream();
	}

	public void write_Object(Object value)
	{
		delegate.write_Object(value);
	}

	public void write_TypeCode(TypeCode value)
	{
		delegate.write_TypeCode(value);
	}

	public void write_any(Any value)
	{
		delegate.write_any(value);
	}

	public void write_boolean(boolean value)
	{
		logger.log(value);
		delegate.write_boolean(value);
	}

	public void write_boolean_array(boolean[] value, int offset, int length)
	{
		logger.log(value);
		delegate.write_boolean_array(value, offset, length);
	}

	public void write_char(char value)
	{
		logger.log(value);
		delegate.write_char(value);
	}

	public void write_char_array(char[] value, int offset, int length)
	{
		logger.log(value);
		delegate.write_char_array(value, offset, length);
	}

	public void write_double(double value)
	{
		logger.log(value);
		delegate.write_double(value);
	}

	public void write_double_array(double[] value, int offset, int length)
	{
		logger.log(value);
		delegate.write_double_array(value, offset, length);
	}

	public void write_float(float value)
	{
		logger.log(value);
		delegate.write_float(value);
	}

	public void write_float_array(float[] value, int offset, int length)
	{
		logger.log(value);
		delegate.write_float_array(value, offset, length);
	}

	public void write_long(int value)
	{
		logger.log(value);
		delegate.write_long(value);
	}

	public void write_long_array(int[] value, int offset, int length)
	{
		logger.log(value);
		delegate.write_long_array(value, offset, length);
	}

	public void write_longlong(long value)
	{
		logger.log(value);
		delegate.write_longlong(value);
	}

	public void write_longlong_array(long[] value, int offset, int length)
	{
		logger.log(value);
		delegate.write_longlong_array(value, offset, length);
	}

	public void write_octet(byte value)
	{
		logger.log(value);
		delegate.write_octet(value);
	}

	public void write_octet_array(byte[] value, int offset, int length)
	{
		logger.log(value);
		delegate.write_octet_array(value, offset, length);
	}

	public void write_short(short value)
	{
		logger.log(value);
		delegate.write_short(value);
	}

	public void write_short_array(short[] value, int offset, int length)
	{
		logger.log(value);
		delegate.write_short_array(value, offset, length);
	}

	public void write_string(String value)
	{
		logger.log(value);
		delegate.write_string(value);
	}

	public void write_ulong(int value)
	{
		logger.log(value);
		delegate.write_ulong(value);
	}

	public void write_ulong_array(int[] value, int offset, int length)
	{
		logger.log(value);
		delegate.write_ulong_array(value, offset, length);
	}

	public void write_ulonglong(long value)
	{
		logger.log(value);
		delegate.write_ulonglong(value);
	}

	public void write_ulonglong_array(long[] value, int offset, int length)
	{
		logger.log(value);
		delegate.write_ulonglong_array(value, offset, length);
	}

	public void write_ushort(short value)
	{
		logger.log(value);
		delegate.write_ushort(value);
	}

	public void write_ushort_array(short[] value, int offset, int length)
	{
		logger.log(value);
		delegate.write_ushort_array(value, offset, length);
	}

	public void write_wchar(char value)
	{
		logger.log(value);
		delegate.write_wchar(value);
	}

	public void write_wchar_array(char[] value, int offset, int length)
	{
		logger.log(value);
		delegate.write_wchar_array(value, offset, length);
	}

	public void write_wstring(String value)
	{
		logger.log(value);
		delegate.write_wstring(value);
	}

}
